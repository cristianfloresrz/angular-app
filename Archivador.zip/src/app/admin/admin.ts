import { CommonModule } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Product, ProductInput } from '../models/Producto';
import { ProductoServices } from '../services/producto-services';

@Component({
  selector: 'app-admin',
  imports: [CommonModule, FormsModule],
  templateUrl: './admin.html',
  styleUrl: './admin.css'
})
export class Admin implements OnInit {
  private productService = inject(ProductoServices);

  products = signal<Product[]>([]);
  categories = signal<string[]>([]);
  loading = signal(true);
  saving = signal(false);
  editingId = signal<number | null>(null);
  error = signal('');
  message = signal('');

  form: ProductInput = this.emptyForm();

  ngOnInit(): void {
    this.loadProducts();
    this.loadCategories();
  }

  loadProducts(): void {
    this.loading.set(true);
    this.error.set('');

    this.productService.getProducts().subscribe({
      next: (data) => {
        this.products.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('No se pudieron cargar los productos.');
        this.loading.set(false);
      }
    });
  }

  loadCategories(): void {
    this.productService.getCategories().subscribe({
      next: (data) => this.categories.set(data),
      error: () =>
        this.categories.set([
          "men's clothing",
          'jewelery',
          'electronics',
          "women's clothing"
        ])
    });
  }

  save(): void {
    this.error.set('');
    this.message.set('');

    if (
      !this.form.title.trim() ||
      !this.form.category ||
      !this.form.image.trim() ||
      Number(this.form.price) <= 0
    ) {
      this.error.set('Completa título, precio, categoría e imagen con valores válidos.');
      return;
    }

    const payload: ProductInput = {
      title: this.form.title.trim(),
      price: Number(this.form.price),
      description: this.form.description.trim(),
      category: this.form.category,
      image: this.form.image.trim()
    };

    this.saving.set(true);
    const id = this.editingId();

    if (id === null) {
      this.productService.createProduct(payload).subscribe({
        next: (product) => {
          this.products.update((list) => [product, ...list]);
          this.message.set(`Producto "${product.title}" creado.`);
          this.saving.set(false);
          this.resetForm();
        },
        error: () => {
          this.error.set('No se pudo crear el producto.');
          this.saving.set(false);
        }
      });
    } else {
      this.productService.updateProduct(id, payload).subscribe({
        next: (product) => {
          this.products.update((list) =>
            list.map((item) => (item.id === id ? { ...item, ...product } : item))
          );
          this.message.set(`Producto "${product.title}" actualizado.`);
          this.saving.set(false);
          this.resetForm();
        },
        error: () => {
          this.error.set('No se pudo actualizar el producto.');
          this.saving.set(false);
        }
      });
    }
  }

  edit(product: Product): void {
    this.editingId.set(product.id);
    this.form = {
      title: product.title,
      price: product.price,
      description: product.description,
      category: product.category,
      image: product.image
    };
    this.error.set('');
    this.message.set('');
  }

  cancelEdit(): void {
    this.resetForm();
  }

  remove(product: Product): void {
    if (!confirm(`¿Eliminar "${product.title}"?`)) {
      return;
    }

    this.error.set('');
    this.message.set('');

    this.productService.deleteProduct(product.id).subscribe({
      next: () => {
        this.products.update((list) => list.filter((item) => item.id !== product.id));
        this.message.set(`Producto "${product.title}" eliminado.`);
        if (this.editingId() === product.id) {
          this.resetForm();
        }
      },
      error: () => this.error.set('No se pudo eliminar el producto.')
    });
  }

  private resetForm(): void {
    this.editingId.set(null);
    this.form = this.emptyForm();
  }

  private emptyForm(): ProductInput {
    return { title: '', price: 0, description: '', category: '', image: '' };
  }
}
